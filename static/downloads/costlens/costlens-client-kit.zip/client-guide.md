# CostLens client guide

CostLens is a read-only AWS cost and resource audit operated by your roussev.dev
consultant. Audits run from the consultant's encrypted workstation; CostLens has
no hosted service that receives your account data. This guide describes the AWS
role, expected charges, audit trail, and data handling before you authorize an
engagement.

## What the CloudFormation stack creates

The supplied template creates one IAM role named `CostLensReadOnly`. Its trust
policy allows only the operator role ARN supplied by your consultant and
requires the unique external ID for your engagement. Do not edit these values or
share the external ID. Deploy the quick-create stack, then send its `RoleArn`
output to your consultant. The role grants read actions only; it does not grant
`Create`, `Put`, `Delete`, `Modify`, IAM administration, or access to S3 objects,
secrets, or parameters. Resource scope is `*` for the read APIs, as required by
many AWS list/describe operations.

| Permission group and actions | What CostLens reads |
| --- | --- |
| Cost Explorer: `ce:GetCostAndUsage`, `ce:GetCostAndUsageWithResources` | Cost and usage totals; resource-level cost where AWS has it enabled. |
| `ce:GetDimensionValues`, `ce:GetTags`, `ce:ListCostAllocationTags` | Available cost dimensions, cost allocation tags and activated tag keys for filtering and grouping. |
| `ce:GetCostForecast` | AWS cost forecasts. |
| `ce:GetAnomalies`, `ce:GetAnomalyMonitors` | Existing cost anomalies and monitor details; CostLens does not create or change monitors. |
| `ce:GetReservationCoverage`, `ce:GetReservationPurchaseRecommendation` | Existing Reserved Instance coverage and AWS recommendations. |
| `ce:GetSavingsPlansCoverage`, `ce:GetSavingsPlansUtilization`, `ce:GetSavingsPlansPurchaseRecommendation` | Existing Savings Plans coverage, utilization and AWS recommendations. |
| Compute Optimizer: `compute-optimizer:Get*`, `compute-optimizer:Describe*` | Read-only recommendations and their details. The wildcards cover only `Get` and `Describe` actions in this service. Existing enrollment is required; CostLens cannot enroll your account. |
| Inventory: `ec2:DescribeRegions`, `ec2:DescribeVolumes`, `ec2:DescribeSnapshots`, `ec2:DescribeImages`, `ec2:DescribeAddresses` | Enabled Regions, EBS volumes, your snapshots and images, and Elastic IP addresses, to identify potential idle or unattached resources. |
| Organizations: `organizations:DescribeOrganization`, `organizations:ListAccounts` | Whether the role is in an Organization and linked account names/IDs. It does not read member-account resources. |
| Tags: `tag:GetResources` | Resource tags that may help explain findings. |

Cost Explorer and Organizations can expose organization-wide billing or account
names when the role is in the management (payer) account. A role in a member or
standalone account provides only that account's cost scope. Inventory and
Compute Optimizer queries run in the account where the role is deployed. The
operator account's public-price lookup permission is separate and is not granted
in your account.

## Cost Explorer charges and approval

AWS charges **$0.01 for each paginated Cost Explorer API request**, billed to
your payer account. The standard audit notice estimates about 29 requests
(roughly $0.29), plus about six requests (roughly $0.06) per activated cost
allocation tag, up to five. Five tags are therefore roughly $0.59 before anomaly
queries, pagination and retries. That is an estimate, not a hard spending limit;
actual requests can vary. Cost Explorer verification also makes a chargeable probe.
Before either operation, the consultant must share the estimate and obtain your
approval. The CLI displays the charge notice before any AWS API call and
requires `--confirm-cost`; after an audit it reports the actual request count
and duration. See [AWS Cost Explorer pricing](https://aws.amazon.com/aws-cost-management/aws-cost-explorer/pricing/).

## Review CostLens access in CloudTrail

CloudTrail Event history records management events by Region and is available
for the last 90 days at no charge. To find CostLens access:

1. Open **CloudTrail → Event history** in the customer account. Select the STS
   Region used for the engagement; ask your consultant which Region is
   configured (the default is `us-east-1`).
2. Filter **Event source** to `sts.amazonaws.com` and **Event name** to
   `AssumeRole`, then set the time range for verification or the audit.
3. Open the event and check `requestParameters.roleArn` for your
   `CostLensReadOnly` role and `requestParameters.roleSessionName` for
   `costlens-verify` or `costlens-<scan-id>`. The scan ID is printed by the CLI
   and included in the report.
4. To review actions performed with the temporary role, search management
   events for the `CostLensReadOnly` assumed-role ARN and session name in the
   Regions where the audited services were queried. Event history is
   Region-specific; use your existing trail or CloudTrail Lake for longer
   retention or cross-Region searches. Trails and CloudTrail Lake can have
   additional AWS storage or query charges.

CloudTrail identifies the assumed role session, not a human name. Keep the
engagement authorization and the consultant's scan ID with your audit records.
AWS documents [Event history](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/view-cloudtrail-events.html)
and the [CloudTrail role-session identity fields](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-event-reference-user-identity.html).

## Revoke access

To prevent future sessions, delete the engagement's CloudFormation stack that
created `CostLensReadOnly` (CloudFormation → Stacks → select the CostLens stack
→ **Delete**). If you need to stop an active scan immediately, first open IAM →
Roles → `CostLensReadOnly` → **Revoke sessions** → **Revoke active sessions**,
then delete the stack. Revocation may take a few minutes to take effect. The
template allows sessions up to one hour; credentials already issued can remain
usable until expiration unless their sessions are revoked. See [AWS's role
session revocation procedure](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_revoke-sessions.html).

## Your data and retention

The consultant records your written authorization before connecting and
confirms full-disk encryption. The workspace is stored locally under
`~/.costlens/engagements/<engagement-id>/` with owner-only directory and file
permissions. It contains connection metadata, the role ARN, external ID,
`report.json`, and rendered deliverables. Reports may include cost data, account
and resource identifiers, Region names and tags. Temporary AWS credentials and
raw API responses are not stored or logged; the external ID is not included in
logs or deliverables.

At engagement end, the consultant asks you to delete the CloudFormation stack
and purges the local workspace within 30 days, unless your signed terms specify
another period. Delivered reports and operator-managed backups follow those
terms. Filesystem purge is not forensic erasure and does not delete copies
already delivered to you. Ask your consultant for a purge confirmation.

## Reports and remediation

`report.json` is the canonical report record. Your consultant can render it as
Markdown, self-contained HTML or CSV; HTML can be printed locally to PDF. Reports
include the scan ID, report date, account scope, catalogue version and any data
gaps. Remediation artifacts are examples for your review, not changes CostLens
makes on your behalf.

CostLens does not apply remediation or make AWS resource changes. You decide
whether to apply any example.

## Authorization record

Use the accompanying [client authorization template](client-authorization-template.md)
to record the approved account scope, engagement dates, authorized contact,
expected Cost Explorer charges and written consent before setup.

## Optional AI host access through local MCP

The optional local MCP server lets a selected AI host query saved reports.
Although the server itself uses local stdio and makes no network calls, the host
can transmit report contents to its model provider. This may include spend,
account/resource identifiers, tags, findings and remediation examples. It must
remain disabled until you authorize the host/provider, purpose, data categories
and applicable retention/training and transfer terms in writing. The standard
read-only AWS audit authorization alone does not authorize this disclosure.

Ask the consultant which host and provider will receive the data and how to
withdraw approval. Stopping the server prevents further queries; deletion of
host/provider copies follows your agreed terms and is separate from local purge.
