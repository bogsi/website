# CostLens client authorization record

Complete and retain this record before running `costlens connect` or making any
AWS API call for the engagement. Adapt it to the signed engagement terms.

## Engagement and scope

- Client legal entity: `[client name]`
- Engagement/reference: `[engagement ID or contract reference]`
- Authorized contact and title: `[name, title, business email]`
- AWS management/payer account ID: `[12-digit account ID]`
- Account scope: `[management account / member account / standalone account]`
- Organization and linked accounts in scope, if applicable: `[IDs or approved scope]`
- Approved audit period and Regions: `[dates and Regions]`
- Operator role ARN to trust: `[provided by roussev.dev consultant]`
- CostLens template version: `[version]`
- Authorization start and expiry/review date: `[date/time and timezone]`

## Cost and data-handling acknowledgement

The client acknowledges that AWS Cost Explorer charges $0.01 per paginated API
request to the payer account. The consultant has supplied the expected request
count and charge for verification and the audit; pagination, anomaly queries,
and retries can change actual usage. The CLI reports the actual Cost Explorer
request count after an audit. CostLens makes no AWS changes, stores reports on
the consultant's encrypted workstation, and purges its local engagement
workspace within 30 days after engagement end unless the signed terms specify
otherwise. The client is responsible for deleting the CloudFormation stack at
engagement end.

- Estimated verification request count/cost: `[count]` / `[$ amount]`
- Estimated audit request count/cost: `[count]` / `[$ amount]`
- Any agreed cost or scope limits: `[limits or “none”]`
- Data retention or deletion terms that differ from the guide: `[terms or “none”]`

## Written authorization

I confirm that I am authorized to approve this AWS read-only cost audit for the
account scope and period above. I authorize the named roussev.dev consultant to
use the CostLens role and read-only permissions described in the [CostLens
client guide](client-guide.md), subject to the engagement terms and approved
Cost Explorer charges above. This authorization does not permit AWS resource
changes or authorize CostLens to apply remediation recommendations.

- Authorized signatory: `[name]`
- Title: `[title]`
- Signature or approved electronic authorization reference: `[signature/reference]`
- Date: `[date]`
- Consultant receiving authorization: `[name]`
- Consultant record location/reference: `[engagement record reference; no credentials]`

## Optional MCP host/provider approval (separate opt-in)

Leave this section unapproved to keep MCP disabled for the engagement.

- Approved host, model provider and model: `[names]`
- Purpose and permitted report data categories: `[scope]`
- Provider retention/training settings and terms reviewed: `[settings/terms reference]`
- Storage location, transfers and approved recipients: `[details]`
- Approval period and withdrawal contact/process: `[details]`
- Handling/deletion of host conversations and provider copies: `[terms]`
- Client signatory, signature/reference and date: `[explicit approval]`

I authorize the specified report data to be processed by the host/provider above
under the stated terms. This approval is separate from AWS role access; revoking
AWS access or purging the local workspace does not erase prior host/provider copies.
