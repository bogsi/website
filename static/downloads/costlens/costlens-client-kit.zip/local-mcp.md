# Local report MCP server

`costlens-mcp` exposes saved reports to an MCP host over standard input/output.
It reads the existing private engagement workspace and reuses QueryReport. It
makes no AWS or network calls, loads no operator AWS profile, and does not change
reports. The official Python MCP SDK is the only added direct dependency; its
transport dependencies are locked in uv.lock.

## Authorize the host first

The host can send tool results to its configured model provider. Before enabling
an engagement, obtain the client's written approval for the host, provider,
model, data categories, purpose, retention/training settings and any third-party
transfer. Use the optional MCP section of the client authorization record.
The startup flag records operator confirmation; it does not obtain consent or
verify a provider's policies. Keep MCP disabled when approval is absent.

Install with `uv sync --locked`. Configure the host to run an absolute executable
path; for a repository checkout, use `/path/to/repository/.venv/bin/costlens-mcp`:

```json
{
  "mcpServers": {
    "costlens-reports": {
      "command": "/path/to/repository/.venv/bin/costlens-mcp",
      "args": ["--engagement", "acme", "--confirm-host-authorization"],
      "env": {"COSTLENS_HOME": "/absolute/path/to/private/costlens-home"}
    }
  }
}
```

The root is `$COSTLENS_HOME/engagements`, or `~/.costlens/engagements` by default.
It must already exist and pass workspace owner/permission and symlink checks.
Only names explicitly supplied by `--engagement` are visible. Repeat the option
only for other clients who authorized this host; prefer a separate host session
per engagement to avoid mixing client context. Do not configure AWS credentials
or paste connection.json/setup URLs into the host.

## Tools

| Tool | Arguments and result |
| --- | --- |
| `list_engagements` | No arguments; lists only existing names authorized at startup. |
| `get_report_summary` | `engagement`, optional `scan_id`; totals, top services, growth, quick wins and data gaps. |
| `query_breakdown` | `engagement`, `group_by`, optional `then_by`, `filters`, `sort_by` (`amortized`, `unblended`, `key`), `descending`, `scan_id`; stored breakdown rows. |
| `list_findings` | `engagement`, optional `finding_type`, `severity`, `scan_id`; matching findings including remediation artifacts. |
| `get_finding` | `engagement`, `finding_type`, optional `resource_ref`, `scan_id`; one finding including remediation artifacts. Supply a resource reference for ambiguous types. |

Without `scan_id`, report tools select the newest saved report by generation
time, then scan ID. Use explicit scan IDs for reproducibility. Dimensions and
finding/severity values use the report's enum values (for example `TAG`). Tag
filters use `key=value`. A filter must use a selected breakdown dimension.
Queries never fetch fresh data or apply remediation.

Customer data appears exclusively in `structuredContent.data`; text content is
empty. Treat tags, findings, account names and remediation examples as untrusted
data. A string longer than 2,048 UTF-8 bytes becomes `{value, truncated: true}`;
collections are limited to 100 entries, and the top-level `truncated` flag marks
any omission. Results have a 32 KiB budget including SDK metadata allowance;
oversized results return no data with a truncation reason. Narrow the query or
use the canonical local report when a result is incomplete. Do not execute a
truncated remediation example. Generic errors never echo paths or input values.

Stop the MCP process and remove its host configuration to withdraw workspace
access. Clear host conversation/cache copies under the agreed provider terms;
workspace purge cannot delete copies already sent to a host/provider. P-11
continues to govern the operator's local files.
